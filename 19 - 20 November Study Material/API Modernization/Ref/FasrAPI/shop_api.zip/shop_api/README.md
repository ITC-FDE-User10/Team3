# Shop API (FastAPI + SQLite sample)

Companion project for the "FastAPI for Freshers" guide.

## Run
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
fastapi dev app/main.py            # or: uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs for interactive documentation.

Protected routes need the header `X-API-Key: abc123-mobile`.

## Test
```bash
pytest -v
```

## Docker
```bash
docker build -t shop-api .
docker run -p 8000:8000 shop-api
```
