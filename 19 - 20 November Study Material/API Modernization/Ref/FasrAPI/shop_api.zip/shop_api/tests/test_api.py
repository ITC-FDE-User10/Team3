import shutil

import pytest
from fastapi.testclient import TestClient

from app.database import DB_PATH, connect, get_db
from app.main import app

AUTH = {"X-API-Key": "abc123-mobile"}


@pytest.fixture
def client(tmp_path):
    """Each test gets a fresh copy of shop.db, so tests never touch real data."""
    test_db = tmp_path / "test.db"
    shutil.copy(DB_PATH, test_db)

    def get_test_db():
        conn = connect(test_db)
        try:
            yield conn
        finally:
            conn.close()

    app.dependency_overrides[get_db] = get_test_db
    yield TestClient(app)
    app.dependency_overrides.clear()


def test_health(client):
    assert client.get("/health").json() == {"status": "UP"}


def test_list_products_filtered(client):
    r = client.get("/products", params={"category": "Electronics", "max_price": 5000})
    assert r.status_code == 200
    assert [p["name"] for p in r.json()] == ["Wireless Mouse", "Mechanical Keyboard"]


def test_get_missing_product_returns_404(client):
    r = client.get("/products/999")
    assert r.status_code == 404
    assert r.json() == {"detail": "Product 999 not found"}


def test_create_product_requires_api_key(client):
    body = {"name": "Webcam HD", "category": "Electronics", "price": 2499}
    assert client.post("/products", json=body).status_code == 401
    r = client.post("/products", json=body, headers=AUTH)
    assert r.status_code == 201
    assert r.json()["product_id"] == 7


def test_validation_error_returns_422(client):
    r = client.post("/products", json={"name": "X", "category": "A", "price": -5}, headers=AUTH)
    assert r.status_code == 422
    fields = {e["loc"][-1] for e in r.json()["detail"]}
    assert fields == {"name", "price"}


def test_place_order_updates_stock(client):
    r = client.post(
        "/orders",
        json={"customer_id": 5, "items": [{"product_id": 2, "quantity": 2}]},
        headers=AUTH,
    )
    assert r.status_code == 201
    assert r.json()["total"] == 6998
    assert client.get("/products/2").json()["stock"] == 38


def test_order_with_too_much_quantity_is_rolled_back(client):
    r = client.post(
        "/orders",
        json={"customer_id": 1, "items": [{"product_id": 3, "quantity": 1},
                                          {"product_id": 5, "quantity": 30}]},
        headers=AUTH,
    )
    assert r.status_code == 409
    assert client.get("/products/3").json()["stock"] == 500   # unchanged
    assert len(client.get("/orders", headers=AUTH).json()) == 6
