from enum import Enum
from typing import Annotated

from fastapi import FastAPI, Path, Query

app = FastAPI()


class Category(str, Enum):
    electronics = "Electronics"
    accessories = "Accessories"
    stationery = "Stationery"


# Path parameter: part of the URL itself -> /items/42
@app.get("/items/{item_id}")
def get_item(item_id: Annotated[int, Path(ge=1)]):
    return {"item_id": item_id}


# Query parameters: after the ? -> /search?q=mouse&limit=5
@app.get("/search")
def search(
    q: Annotated[str, Query(min_length=2)],          # required
    limit: Annotated[int, Query(ge=1, le=50)] = 10,  # optional, default 10
    in_stock: bool = False,                          # ?in_stock=true
):
    return {"q": q, "limit": limit, "in_stock": in_stock}


# Enum: only these values are accepted, and /docs shows a dropdown
@app.get("/categories/{category}")
def by_category(category: Category):
    return {"category": category.value}
