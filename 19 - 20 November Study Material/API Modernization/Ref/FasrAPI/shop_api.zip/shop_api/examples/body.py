from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI()


class Customer(BaseModel):
    name: str = Field(min_length=2, max_length=50)
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[a-z]{2,}$")
    city: str | None = None          # optional
    age: int = Field(ge=18, le=120)


@app.post("/customers", status_code=201)
def create_customer(customer: Customer):
    # 'customer' is already parsed and validated here
    return {"saved": customer.model_dump()}
