import asyncio
import time

from fastapi import FastAPI

app = FastAPI()


@app.get("/sync")
def sync_endpoint():
    time.sleep(1)               # blocking call -> use plain def
    return {"type": "sync"}     # FastAPI runs it in a thread pool


@app.get("/async")
async def async_endpoint():
    await asyncio.sleep(1)      # non-blocking call -> use async def
    return {"type": "async"}
