from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def read_root():
    return {"message": "Hello, FastAPI!"}


@app.get("/greet/{name}")
def greet(name: str, times: int = 1):
    return {"greeting": f"Hello {name}! " * times}
