import logging
import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from .routers import orders, products

logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="Shop API",
    version="1.0.0",
    description="Sample REST API over shop.db, built for the FastAPI freshers guide.",
)

# Allow a front-end running on another origin (e.g. React dev server) to call us
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_process_time(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Process-Time-ms"] = f"{(time.perf_counter() - start) * 1000:.1f}"
    return response


@app.get("/health", tags=["Health"])
def health():
    return {"status": "UP"}


app.include_router(products.router)
app.include_router(orders.router)
