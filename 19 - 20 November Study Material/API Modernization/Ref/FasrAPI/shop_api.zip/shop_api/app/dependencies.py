import sqlite3
from typing import Annotated

from fastapi import Depends, Header, HTTPException, Query, status

from .database import get_db

# Reusable type alias: "a DB connection provided by get_db"
DB = Annotated[sqlite3.Connection, Depends(get_db)]

# Demo only. In real projects, load keys from environment variables or a vault.
API_KEYS = {"abc123-mobile": "mobile-app", "xyz789-partner": "partner-portal"}


def verify_api_key(x_api_key: Annotated[str | None, Header()] = None) -> str:
    """Reads the X-API-Key header and returns the client name, or rejects."""
    client = API_KEYS.get(x_api_key or "")
    if client is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )
    return client


def pagination(
    limit: Annotated[int, Query(ge=1, le=100)] = 10,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> dict:
    return {"limit": limit, "offset": offset}


Page = Annotated[dict, Depends(pagination)]
