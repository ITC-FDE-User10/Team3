import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "shop.db"


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    """Open a SQLite connection configured the way our app needs it."""
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row             # rows behave like dicts
    conn.execute("PRAGMA foreign_keys = ON")   # enforce relationships
    return conn


def get_db():
    """Dependency: one connection per request, always closed afterwards."""
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()
