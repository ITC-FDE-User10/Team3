from typing import Literal

from pydantic import BaseModel, Field

OrderStatus = Literal["PLACED", "SHIPPED", "DELIVERED", "CANCELLED"]


# ---------- Products ----------
class ProductBase(BaseModel):
    name: str = Field(min_length=2, max_length=100, examples=["Webcam HD"])
    category: str = Field(examples=["Electronics"])
    price: float = Field(gt=0, examples=[2499])
    stock: int = Field(default=0, ge=0)


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    """All fields optional: send only what you want to change."""
    name: str | None = Field(default=None, min_length=2, max_length=100)
    category: str | None = None
    price: float | None = Field(default=None, gt=0)
    stock: int | None = Field(default=None, ge=0)


class Product(ProductBase):
    product_id: int


# ---------- Orders ----------
class OrderItemIn(BaseModel):
    product_id: int
    quantity: int = Field(gt=0, le=50)


class OrderCreate(BaseModel):
    customer_id: int
    items: list[OrderItemIn] = Field(min_length=1)


class OrderItemOut(BaseModel):
    product_id: int
    name: str
    quantity: int
    unit_price: float


class Order(BaseModel):
    order_id: int
    customer_id: int
    order_date: str
    status: OrderStatus
    total: float
    items: list[OrderItemOut]


class OrderSummary(BaseModel):
    order_id: int
    customer: str
    order_date: str
    status: OrderStatus
    total: float


class StatusUpdate(BaseModel):
    status: OrderStatus
