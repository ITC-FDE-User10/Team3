import logging
import sqlite3

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status

from ..dependencies import DB, verify_api_key
from ..schemas import Order, OrderCreate, OrderStatus, OrderSummary, StatusUpdate

log = logging.getLogger("shop")

# Every route in this router requires a valid API key
router = APIRouter(
    prefix="/orders", tags=["Orders"], dependencies=[Depends(verify_api_key)]
)


def fetch_order(order_id: int, db: sqlite3.Connection) -> dict:
    order = db.execute(
        "SELECT * FROM orders WHERE order_id = ?", (order_id,)
    ).fetchone()
    if order is None:
        raise HTTPException(status_code=404, detail=f"Order {order_id} not found")
    items = [
        dict(r)
        for r in db.execute(
            """SELECT oi.product_id, p.name, oi.quantity, oi.unit_price
               FROM order_items oi JOIN products p USING (product_id)
               WHERE oi.order_id = ?""",
            (order_id,),
        )
    ]
    total = round(sum(i["quantity"] * i["unit_price"] for i in items), 2)
    return {**dict(order), "total": total, "items": items}


def send_confirmation(order_id: int) -> None:
    """Pretend to send an email. Runs AFTER the response is returned."""
    log.info("Confirmation email queued for order %s", order_id)


@router.get("", response_model=list[OrderSummary])
def list_orders(db: DB, status: OrderStatus | None = None):
    sql, params = "SELECT * FROM order_summary", []
    if status:
        sql += " WHERE status = ?"
        params.append(status)
    return [dict(r) for r in db.execute(sql + " ORDER BY order_id", params)]


@router.get("/{order_id}", response_model=Order)
def get_order(order_id: int, db: DB):
    return fetch_order(order_id, db)


@router.post("", response_model=Order, status_code=status.HTTP_201_CREATED)
def create_order(order: OrderCreate, db: DB, background_tasks: BackgroundTasks):
    customer = db.execute(
        "SELECT 1 FROM customers WHERE customer_id = ?", (order.customer_id,)
    ).fetchone()
    if customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    try:
        with db:  # ONE transaction: the order, its items and stock updates
            cur = db.execute(
                "INSERT INTO orders (customer_id, order_date) VALUES (?, date('now'))",
                (order.customer_id,),
            )
            order_id = cur.lastrowid
            for item in order.items:
                p = db.execute(
                    "SELECT name, price, stock FROM products WHERE product_id = ?",
                    (item.product_id,),
                ).fetchone()
                if p is None:
                    raise HTTPException(404, f"Product {item.product_id} not found")
                if p["stock"] < item.quantity:
                    raise HTTPException(409, f"Only {p['stock']} left of {p['name']}")
                db.execute(
                    "INSERT INTO order_items VALUES (?, ?, ?, ?)",
                    (order_id, item.product_id, item.quantity, p["price"]),
                )
                db.execute(
                    "UPDATE products SET stock = stock - ? WHERE product_id = ?",
                    (item.quantity, item.product_id),
                )
    except sqlite3.IntegrityError:
        raise HTTPException(400, "Each product may appear only once per order")

    background_tasks.add_task(send_confirmation, order_id)
    return fetch_order(order_id, db)


@router.patch("/{order_id}/status", response_model=Order)
def update_status(order_id: int, body: StatusUpdate, db: DB):
    fetch_order(order_id, db)
    with db:
        db.execute(
            "UPDATE orders SET status = ? WHERE order_id = ?", (body.status, order_id)
        )
    return fetch_order(order_id, db)
