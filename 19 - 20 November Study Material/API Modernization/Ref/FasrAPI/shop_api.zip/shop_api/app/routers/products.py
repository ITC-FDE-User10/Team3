import sqlite3
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from ..dependencies import DB, Page, verify_api_key
from ..schemas import Product, ProductCreate, ProductUpdate

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("", response_model=list[Product])
def list_products(
    db: DB,
    page: Page,
    category: str | None = None,
    max_price: Annotated[float | None, Query(gt=0)] = None,
):
    """List products, optionally filtered by category and maximum price."""
    sql, params = "SELECT * FROM products WHERE 1 = 1", []
    if category:
        sql += " AND category = ?"
        params.append(category)
    if max_price is not None:
        sql += " AND price <= ?"
        params.append(max_price)
    sql += " ORDER BY product_id LIMIT ? OFFSET ?"
    rows = db.execute(sql, [*params, page["limit"], page["offset"]]).fetchall()
    return [dict(r) for r in rows]


@router.get("/{product_id}", response_model=Product)
def get_product(product_id: int, db: DB):
    row = db.execute(
        "SELECT * FROM products WHERE product_id = ?", (product_id,)
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
    return dict(row)


@router.post(
    "",
    response_model=Product,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(verify_api_key)],
)
def create_product(product: ProductCreate, db: DB):
    with db:  # commits on success, rolls back on error
        cur = db.execute(
            "INSERT INTO products (name, category, price, stock) VALUES (?, ?, ?, ?)",
            (product.name, product.category, product.price, product.stock),
        )
    return {"product_id": cur.lastrowid, **product.model_dump()}


@router.patch(
    "/{product_id}", response_model=Product, dependencies=[Depends(verify_api_key)]
)
def update_product(product_id: int, changes: ProductUpdate, db: DB):
    data = changes.model_dump(exclude_unset=True)   # only fields the client sent
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update")
    get_product(product_id, db)                      # 404 if it doesn't exist
    # Column names come from our Pydantic model (not user text), so this is safe.
    set_clause = ", ".join(f"{col} = ?" for col in data)
    with db:
        db.execute(
            f"UPDATE products SET {set_clause} WHERE product_id = ?",
            [*data.values(), product_id],
        )
    return get_product(product_id, db)


@router.delete(
    "/{product_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(verify_api_key)],
)
def delete_product(product_id: int, db: DB):
    get_product(product_id, db)
    try:
        with db:
            db.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
    except sqlite3.IntegrityError:
        raise HTTPException(
            status_code=409, detail="Product is part of existing orders"
        )
